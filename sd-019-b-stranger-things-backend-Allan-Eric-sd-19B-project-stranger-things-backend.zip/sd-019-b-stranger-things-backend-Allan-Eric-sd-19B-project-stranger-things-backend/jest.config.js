module.exports = {
    rootDir: './tests',
    testRegex: './*\\.test\\.js$',
    testTimeout: 120000,
  };